#define TAMANHO_PALAVRA 20

void abertura();
void chuta();
void desenhaforca();
void escolhepalavra();
int acertou();
int enforcou();
int jachutou(char letra);