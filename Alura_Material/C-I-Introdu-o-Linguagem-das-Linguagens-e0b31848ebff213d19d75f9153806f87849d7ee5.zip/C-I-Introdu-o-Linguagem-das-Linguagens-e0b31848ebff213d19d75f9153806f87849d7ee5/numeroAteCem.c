#include <stdio.h>

int main() {
  // repare no menor-igual
  for(int i = 1; i <= 100; i++) {
    printf("%d \n", i);
  }
  //while(numero <= 100) {
  //  printf("%d\n ", numero);
  //  numero++;
  //}
}