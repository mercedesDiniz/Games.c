#ifndef _UI_H_
#define _UI_H_

#include "mapa.h"

void imprimeparte(char desenho[4][7], int parte);
void imprimemapa(MAPA* m);

#endif