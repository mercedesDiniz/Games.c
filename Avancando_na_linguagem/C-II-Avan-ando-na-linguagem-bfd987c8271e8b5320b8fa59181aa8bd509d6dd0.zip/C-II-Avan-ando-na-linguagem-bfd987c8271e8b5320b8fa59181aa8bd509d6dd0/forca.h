void abertura();
void chuta();
void desenhaforca();
void escolhepalavra();
int acertou();
int enforcou();
int jachutou(char letra);