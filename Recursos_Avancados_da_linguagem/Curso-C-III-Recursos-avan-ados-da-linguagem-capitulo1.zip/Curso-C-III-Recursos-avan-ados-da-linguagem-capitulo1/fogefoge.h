void alocamapa();
void lemapa();
void liberamapa();