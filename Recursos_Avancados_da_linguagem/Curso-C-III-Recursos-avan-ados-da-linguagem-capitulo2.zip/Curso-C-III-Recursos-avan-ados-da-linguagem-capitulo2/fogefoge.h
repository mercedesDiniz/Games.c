int acabou();
void move(char direcao);